library(readr)
Data <- read_delim("export-data_survey/all-questions-likert-and-tool-new.csv", 
                   "\t", escape_double = FALSE, trim_ws = TRUE)

Input <- as.data.frame(Data)

Input <- subset(Input, Transformation!="512" & Transformation!="511" & Transformation!="518" & Transformation!="481")
Input <- subset(Input, Transformation!="534" & Transformation!="463" & Transformation!="535" & Transformation!="539")

Input$Tool[Input$Tool == "netbeans"] <- "NetBeans"
Input$Tool[Input$Tool == "intellj"] <- "Intellij"
Input$Tool[Input$Tool == "rjtl"] <- "Rjtl"
Input$`NewType-1`[Input$`NewType-1` == "ForLoop To Functional Refactoring"] <- "For Loop To Functional Refactoring"

Input1 <- subset(Input, Transformation == "515")
Input2 <- subset(Input, Transformation == "517")
# Input3 <- subset(Input, Transformation == "462")

Input <- rbind(Input1, Input2)
# Input <- rbind(Input, Input3)

library(plyr)
count(Input, 'Participant')