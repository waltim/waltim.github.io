library(readr)
Data <- read_delim("export-data_survey/users-by-country.csv",
                   ";", escape_double = FALSE, trim_ws = TRUE)



Data <- subset(Data, participant_count>2)
Data <- Data[order(Data$participant_count,decreasing = TRUE),]

slices <- c(Data$participant_count)
lbls <- c(Data$country)

library(plotly)

fig <- plot_ly(Data, labels = lbls, values = slices, type = 'pie')
fig <- fig %>% layout(title = 'Developers by countries',
                      xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                      yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

fig
