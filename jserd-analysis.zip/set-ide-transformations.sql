SET SQL_SAFE_UPDATES = 0;

UPDATE users SET users.country = "N/A" where trophy >=7 and country is null;

ALTER TABLE transformations ADD COLUMN ide VARCHAR(100) NULL AFTER apt;
ALTER TABLE transformations ADD COLUMN is_cascade VARCHAR(100) NULL AFTER ide;

UPDATE transformations SET transformations.ide = "intellj" WHERE diff_id like "%intellj%";
UPDATE transformations SET transformations.ide = "netbeans" WHERE diff_id like "%netbeans%";
UPDATE transformations SET transformations.ide = "rjtl" WHERE diff_id like "%rjtl%";