install.packages("tm", dependencies = TRUE)
install.packages("SnowballC", dependencies = TRUE)
install.packages("wordcloud", dependencies = TRUE)


library(tm)
library(SnowballC)
library(wordcloud)