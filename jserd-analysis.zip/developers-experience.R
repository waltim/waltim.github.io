if(!require(psych)){install.packages("psych")}
if(!require(FSA)){install.packages("FSA")}
if(!require(lattice)){install.packages("lattice")}
if(!require(coin)){install.packages("coin")}
if(!require(rcompanion)){install.packages("rcompanion", dependencies=TRUE)}
if(!require(multcompView)){install.packages("multcompView")}
if(!require(ggplot2)){install.packages("ggplot2")}
if(!require(plyr)){install.packages("plyr")}


Data <- read.csv("/home/walterlucas/export-data_survey/q1-by-type.csv", header = TRUE, sep = ",")
Data

Data$Profession <- revalue(Data$Profession, c("dfullst"="Developer, full-stack"))
Data$Profession <- revalue(Data$Profession, c("dback"="Developer, back-and"))
Data$Profession <- revalue(Data$Profession, c("dmbile"="Others"))

Data$Formation <- revalue(Data$Formation, c("dd"="Doctorate degree"))
Data$Formation <- revalue(Data$Formation, c("under"="Undergraduate"))
Data$Formation <- revalue(Data$Formation, c("md"="Master’s degree"))
Data$Formation <- revalue(Data$Formation, c("bd"="Bachelor’s degree"))
Data$Formation <- revalue(Data$Formation, c("hsg"="High school graduate"))
Data$Formation <- revalue(Data$Formation, c("hsn"="Some high school"))

#library(dplyr)

# distinct
#Data <- Data %>% distinct(Participant, .keep_all = T)

#summary(Data)

Input <- Data[ , -which(names(Data) %in% c("Participant","Profession","Formation","Transformation","Type"))]
Input  
colnames(Input) <- c("DevExperience", "Q1")
#Input
#Input<-Input[!(Input$Employment=="dmbile"),]
#Input
levels(Input$DevExperience) <- c("less than one year", "between one and four years", "between five and ten years", "more than ten years")
#levels(Input$Employment) <- c("dmbile","dfullst", "dback")
#levels(Input$Formation) <- c("dd", "under", "md", "bd", "hsg","hsn")

Input$DevExperience <- as.character(Input$DevExperience)

#Input$Employment <- revalue(Input$Employment, c("dfullst"="Developer, full-stack"))
#Input$Employment <- revalue(Input$Employment, c("dback"="Developer, back-and"))
#Input$Employment <- revalue(Input$Employment, c("dmbile"="Others"))

 # Input$Formation <- revalue(Input$Formation, c("dd"="Doctorate degree"))
 # Input$Formation <- revalue(Input$Formation, c("under"="Undergraduate"))
 # Input$Formation <- revalue(Input$Formation, c("md"="Master’s degree"))
 # Input$Formation <- revalue(Input$Formation, c("bd"="Bachelor’s degree"))
 # Input$Formation <- revalue(Input$Formation, c("hsg"="High school graduate"))
 # Input$Formation <- revalue(Input$Formation, c("hsn"="Some high school"))

 # Input$Formation = factor(Input$Formation, levels=c("Some high school",
 # "High school graduate","Undergraduate", "Bachelor’s degree",
 # "Master’s degree","Doctorate degree"))

 Input$DevExperience = factor(Input$DevExperience, levels=c("less than one year", "between one and four years", "between five and ten years", "more than ten years"))

#Input$Employment = factor(Input$Employment, levels=c("Others", "Developer, back-and", "Developer, full-stack"))
Input

Input$Likert.f = factor(Input$Q1,
                        ordered = TRUE)
levels(Input$Likert.f) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")
colnames(Input) <- c("DevExperience", "Q1", "Level")

library(psych)

headTail(Input)

str(Input)

summary(Input)

xtabs( ~ DevExperience + Level,
       data = Input)

XT = xtabs( ~ DevExperience + Level,
            data = Input)

prop.table(XT, 
           margin = 1)

library(lattice)

histogram(~ Level | DevExperience,
          data=Input,
          layout=c(1,4),
          xlab = "Level of Agreement", ylab = "Developer Experience",
)

library(coin)
library(rcompanion)


options("scipen"=100, "digits"=4)

independence_test(Level ~ DevExperience,data = Input)
PT = pairwisePermutationTest(Level ~ DevExperience, data = Input, method = "fdr")
PT