SELECT DISTINCT(u.country), (SELECT COUNT(users.country) 
from users WHERE users.country = u.country and users.trophy > 0) AS participant_count 
FROM `answers` INNER JOIN users AS u ON answers.user_id = u.id
ORDER BY 2 desc;