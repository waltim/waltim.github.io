-- SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

select x.experience as Java_Experience, x.formation as Formation,
 x.profession as Profession, 
x.user_id as Participant, x.transformation_id as Transformation, x.description as Type 
,x.choice as Q1
from 
(SELECT ul.experience, u.profession, u.formation, an.user_id, res.transformation_id,ty.description, qst.id, an.choice

FROM users u
inner join user_languages as ul on ul.user_id = u.id
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as ty on tr.transformation_type_id = ty.id
where u.trophy >= 7 and qst.id = 2) x

group by 4,5
order by 6