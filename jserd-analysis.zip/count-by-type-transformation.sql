SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

SELECT DISTINCT(ty.description), (SELECT COUNT(transformations.id) 
from transformations WHERE transformations.transformation_type_id = ty.id) AS Transformation_count 
FROM transformation_types as ty INNER JOIN transformations AS t ON t.transformation_type_id = ty.id
-- WHERE t.ide = "rjtl";