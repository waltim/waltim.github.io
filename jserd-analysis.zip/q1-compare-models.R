library(readr)
Data <- read_delim("export-data_survey/all-questions-likert-and-tool.csv",
                   ";", escape_double = FALSE, trim_ws = TRUE)

Data$Tool[Data$Tool == "netbeans"] <- "NetBeans"
Data$Tool[Data$Tool == "intellj"] <- "Intellij"
Data$Tool[Data$Tool == "rjtl"] <- "Rjtl"

#Data <- subset(Data, Tool == "Intellij")

Input <- Data[ , -which(names(Data) %in% c("Participant","Tool","Type","Q2","Q3","Q4","Q5","Q6"))]

Data2 <- read_delim("export-data_survey/all-metrics-and-models-by-transformation.csv", 
                                                       "\t", escape_double = FALSE, trim_ws = TRUE)

Data2$Tool <- as.character(Data2$Tool)

Data2$Tool[Data2$Tool == "netbeans"] <- "NetBeans"
Data2$Tool[Data2$Tool == "intellj"] <- "Intellij"
Data2$Tool[Data2$Tool == "rjtl"] <- "Rjtl"

Data2 <- subset(Data2, `_Type` == "Anonymous Inner Class To Lambda Expression")

Input2 <- Data2[ , -which(names(Data2) %in% c("diff_id","_Type","Tool","Complex_Before","Complex_After",
                                              "Loc_Before", "Loc_After","PosnettDiff","BuseDiff","posnett","buse"))]
Input2 <- as.data.frame(Input2)

df<-merge(x=Input,y=Input2,by="Transformation")

summary(df)

df$Posnet_After <- gsub(",", ".", df$Posnet_After)
df$RayBuse_After <- gsub(",", ".", df$RayBuse_After)
df$Posnet_After<-as.double(df$Posnet_After)
df$RayBuse_After<-as.double(df$RayBuse_After)

mean(df$Posnet_After)
mean(df$RayBuse_After)

df$Q1 = factor(df$Q1,
               levels = c("1", "2", "3", "4", "5"),
               ordered = TRUE)

levels(df$Q1) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")

library(psych)

library(likert)

items29 <- as.data.frame(df[ , -which(names(df) %in% c("Transformation","RayBuse_Before","Posnet_After","Posnet_Before","RayBuse_After"))])
names(items29) = c("")
l29gs <- likert(items29, grouping = df$Transformation)
str(l29gs$results)

lr <- summary(l29gs)[ , -which(names(summary(l29gs)) %in% c("Item","low","neutral","mean","sd"))]
lr2 <- summary(l29gs)[ , -which(names(summary(l29gs)) %in% c("Item","mean","sd"))]
lr2["Improvement"] <- ifelse(lr2$low < lr2$high, "Increase", ifelse(lr2$low > lr2$high, "Decrease", "Unchanged"))
lr2$Improvement <- as.factor(lr2$Improvement)
summary(lr2)
names(lr) = c("Transformation", "Developers")

lr$Developers <-as.double(lr$Developers)
#lr$Developers <- (lr$Developers / 100)

subdf2 <- Data2[ , -which(names(Data2) %in% c("diff_id","_Type","Tool","Complex_Before","Complex_After",
                                             "Loc_Before", "Loc_After","Q1","PosnettDiff","BuseDiff","posnett","buse"))]

subdf2["PImprovement"] <- ifelse(subdf2$Posnet_Before < subdf2$Posnet_After, "Increase", ifelse(subdf2$Posnet_Before > subdf2$Posnet_After, "Decrease", "Unchanged"))
subdf2["BImprovement"] <- ifelse(subdf2$RayBuse_Before < subdf2$RayBuse_After, "Increase", ifelse(subdf2$RayBuse_Before > subdf2$RayBuse_After, "Decrease", "Unchanged"))
subdf2$PImprovement <- as.factor(subdf2$PImprovement)
subdf2$BImprovement <- as.factor(subdf2$BImprovement)

summary(subdf2$PImprovement)
summary(subdf2$BImprovement)
summary(lr2$Improvement)

# subdf <- Data2[ , -which(names(Data2) %in% c("diff_id","_Type","Tool","Complex_Before","Complex_After",
#                                              "Loc_Before", "Loc_After","Q1","Posnet_Before","RayBuse_Before","PosnettDiff","BuseDiff","posnett","buse"))]

subdf$Posnet_After <- gsub(",", ".", subdf$Posnet_After)
subdf$RayBuse_After <- gsub(",", ".", subdf$RayBuse_After)
subdf$Posnet_After<-as.double(subdf$Posnet_After)
subdf$RayBuse_After<-as.double(subdf$RayBuse_After)
subdf$Posnet_After <- subdf$Posnet_After * 100
subdf$RayBuse_After <- subdf$RayBuse_After * 100
names(subdf) = c("Transformation", "Posnett","Buse")

finalResults <- merge(x=subdf,y=lr,by="Transformation")

#finalResults <- finalResults[sample(nrow(finalResults), 30), ]

library(dplyr)
library(ggpubr)
prescriptionMelted <- reshape2::melt(finalResults, id.var='Transformation')
head(prescriptionMelted)
names(prescriptionMelted) = c("Transformation", "Evaluator","value")
#prescriptionMelted$Transformation <- as.numeric(prescriptionMelted$Transformation)
lapply(prescriptionMelted, class)

ggplot(prescriptionMelted,text.size=7, cex.lab = 5, aes(x=Transformation, y=value, col=Evaluator)) + theme(axis.text = element_text(size="18")) + geom_line() + labs(x = "Transformations (ID)", y = "Readability (%)")
