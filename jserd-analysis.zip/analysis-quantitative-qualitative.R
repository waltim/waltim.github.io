library(readr)
Data <- read_delim("export-data_survey/all-questions-likert-and-tool.csv",
                   ";", escape_double = FALSE, trim_ws = TRUE)

Input <- Data[ , -which(names(Data) %in% c("Participant","Tool","Type","Q2","Q3","Q4","Q5","Q6"))]

Data2 <- read.csv("export-data_survey/all-metrics-and-models-by-transformation.csv",head=T, sep=";")
Input2 <- Data2[ , -which(names(Data2) %in% c("diff_id","X_Type","Tool","Complex_Before","Complex_After",
                                              "Posnet_Before", "Posnet_After","RayBuse_Before","RayBuse_After"))]
Input2 <- as.data.frame(Input2)

df<-merge(x=Input,y=Input2,by="Transformation")

df["Difference"] <- df$Loc_Before - df$Loc_After

df["Succinct"] <- ifelse(df$Difference < 0, "More verbose", ifelse(df$Difference == 0, "Equal", "More Succinct"))

summary(df)

df$Q1 = factor(df$Q1,
                  levels = c("1", "2", "3", "4", "5"),
                  ordered = TRUE)

df$Succinct = factor(df$Succinct,
               levels = c("More verbose","Equal","More Succinct"),
               ordered = TRUE)

levels(df$Q1) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")

library(psych)

library(likert)

items29 <- as.data.frame(df[ , -which(names(df) %in% c("Transformation","Loc_Before","Loc_After","Difference","Succinct"))])
names(items29) = c("Code more succinct makes comprehension easier?")
l29gs <- likert(items29, grouping = df$Succinct)
str(l29gs$results)
summary(l29gs)

pdf("/home/walterlucas/export-data_survey/succcinct.pdf", width = 20, height = 20)
plot(l29gs, wrap = 100, text.size=8, cex.lab = 5) + theme(axis.text.y = element_text(size="15", face = "bold"))
dev.off()