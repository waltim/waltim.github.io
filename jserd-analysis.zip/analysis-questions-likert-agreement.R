# library(readr)
# Data <- read_delim("export-data_survey/all-questions-likert-and-tool.csv",
# ";", escape_double = FALSE, trim_ws = TRUE)

library(readr)
Data <- read_delim("export-data_survey/all-questions-likert-and-tool-new.csv", 
                   "\t", escape_double = FALSE, trim_ws = TRUE)
#View(Data)

# Input <- Data[ , -which(names(Data) %in% c("Participant"))]
# Input <- as.data.frame(Input)

Input <- as.data.frame(Data)


Input$Tool[Input$Tool == "netbeans"] <- "NetBeans"
Input$Tool[Input$Tool == "intellj"] <- "Intellij"
Input$Tool[Input$Tool == "rjtl"] <- "Rjtl"
Input$`NewType-1`[Input$`NewType-1` == "ForLoop To Functional Refactoring"] <- "For Loop To Functional Refactoring"

# Input <- subset(Input, Transformation!="512" & Transformation!="511" & Transformation!="518" & Transformation!="481")
# Input <- subset(Input, Transformation!="534" & Transformation!="463" & Transformation!="535" & Transformation!="539")

#Input <- subset(Input, Tool == "Rjtl")
#Input <- subset(Input, Tool == "Intellij")
#Input <- subset(Input, Tool == "NetBeans")

Input1 <- subset(Input, Transformation == "533")
Input2 <- subset(Input, Transformation == "498")
Input3 <- subset(Input, Transformation == "462")

# Input <- merge(x = Input1, y = Input2)
# Input <- merge(x = Input, y = Input3)
Input <- rbind(Input1, Input2)
Input <- rbind(Input, Input3)

#Input <- subset(Input, `NewType-2` == "Chaining")

Input$Q1 = factor(Input$Q1,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Input$Q2 = factor(Input$Q2,
                     levels = c("1", "2", "3", "4", "5"),
                     ordered = TRUE)

Input$Q3 = factor(Input$Q3,
                     levels = c("1", "2", "3", "4", "5"),
                     ordered = TRUE)

Input$Q4 = factor(Input$Q4,
                     levels = c("1", "2", "3", "4", "5"),
                     ordered = TRUE)

Input$Q5 = factor(Input$Q5,
                     levels = c("1", "2", "3", "4", "5"),
                     ordered = TRUE)

Input$Q6 = factor(Input$Q6,
                     levels = c("1", "2", "3", "4", "5"),
                     ordered = TRUE)

levels(Input$Q1) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")
levels(Input$Q2) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")
levels(Input$Q3) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")
levels(Input$Q4) <- c("Strongly Disagree", "Disagree", "Neither agree or disagree", "Agree", "Strongly Agree")
levels(Input$Q5) <- c("Never", "Rarely", "Sometimes", "Often", "Always")
levels(Input$Q6) <- c("Not important at all", "Low importance", "Neutral", "Moderately", "Very important")

#Question <- as.data.frame(Input[ , -which(names(Input) %in% c("Tool","Type","Q1","Q2","Q3","Q4","Q5","Q6"))])

library(psych)

library(likert)

items29 <- as.data.frame(Input[ , -which(names(Input) %in% c("Participant","Tool","Transformation","Type","NewType-1","NewType-2","Q2","Q5","Q6","Q4","Q3"))])
items29
ncol(items29)
names(items29) = c("")
#names(items29) = c("Anonymous Inner Class To Lambda Expression")

#names(items29) = c("The new code is easier to comprehend.")
#names(items29) = c("The new code is more succinct and readable.")
#names(items29) = c("The intention of using a lambda expression in the new code is clear.")
#names(items29) = c("The new code is harder to debug.")
#names(items29) = c("How often would you perform this type of transformation?")
#names(items29) = c("How important is the automated support for this kind of transformation?")

# names(items29) = c("The new code is easier to comprehend.", "The new code is more succinct and readable."
#                    , "The intention of using a lambda expression in the new code is clear."
#                    , "The new code is harder to debug.",
#                    "How often would you perform this type of transformation?",
#                    "How important is the automated support for this kind of transformation?")
head(items29)

title <- "What is your opinion about the following sentences:"

#l29gs <- likert(items29, grouping = Input$Type)
#l29gs <- likert(items29, grouping = Input$Transformation)
#l29gs <- likert(items29, grouping = Input$`NewType-2`)
l29gs <- likert(items29)
summary(items29)
str(l29gs$results)

#summary(l29gs)
# tabresults <- summary(l29gs)
# tabresults <- as.data.frame(tabresults[ , -which(names(tabresults) %in% c("Item","mean","sd"))])
# names(tabresults) = c("ID","Low","Neutral","High")
# tabresults[, 2:4] <- round(tabresults[, 2:4], digits = 2)
#write.csv(tabresults,"/home/walterlucas/export-data_survey/transformation-id-and-evaluates.csv", row.names = TRUE)

# plot(l29gs, centered=FALSE, type = bar) + ggtitle(title)
# pdf("/home/walterlucas/export-data_survey/intellij-q1.pdf", width = 20, height = 6)
# plot(l29gs, wrap = 100, text.size=8, cex.lab = 5) + theme(axis.text.y = element_text(size="15")) + ggtitle(title) +
#   theme(plot.title = element_text(hjust = 0.5, size = 15, face = "bold"))
# dev.off()

#pdf("/home/walterlucas/export-data_survey/q1-two.pdf", width = 20, height = 20)
# plot(l29gs, wrap = 100, text.size=7, cex.lab = 5) + theme(axis.text = element_text(size="18"))
#+ ggtitle(title) + theme(plot.title = element_text(hjust = 0.5, size = 15, face = "bold"))
#dev.off()

#
# lik2 <- likert(items29, grouping = Input$`NewType-2`)
lik2 <- likert(items29, grouping = Input$Transformation)
plot(lik2, wrap = 60, text.size=4) + theme(axis.text.y = element_text(size="10"))