SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

select x.user_id as Participant, x.transformation_id as Transformation,
x.ide as Tool, x.description as Type 
, x.choice as Q1
, y.choice as Q2
, z.choice as Q3
, j.choice as Q4
, h.choice as Q5
, w.choice as Q6
from 
(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 2) x

inner join 

(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 11) y on x.user_id = y.user_id

inner join

(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 12) z on x.user_id = z.user_id

inner join 

(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 13) j on x.user_id = j.user_id

inner join 

(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 14) h on x.user_id = h.user_id

inner join 

(SELECT an.user_id, res.transformation_id,tr.ide,typ.description, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 15) w on x.user_id = w.user_id

group by 1,2
order by 1,3