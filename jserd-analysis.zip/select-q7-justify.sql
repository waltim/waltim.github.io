SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

select x.user_id as Participant, x.transformation_id as Transformation, x.description as Type 
, x.justify as Q7
from 
(SELECT an.user_id, res.transformation_id,typ.description, qst.id, an.justify

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as typ on transformation_type_id = typ.id
where u.trophy >= 7 and qst.id = 16 and an.justify != 'N/A') x

group by 1,2
order by 3