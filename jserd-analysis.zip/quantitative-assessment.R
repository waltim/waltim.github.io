library(readr)
Data <- read_delim("export-data_survey/all-metrics-and-models-by-transformation-new.csv", 
                                                           "\t", escape_double = FALSE, trim_ws = TRUE)
Input <- Data[ , -which(names(Data) %in% c("diff_id","_Type","NewType-1","NewType-2"))]
Input <- as.data.frame(Input)
Input$Tool <- as.character(Input$Tool)

Input$Tool[Input$Tool == "netbeans"] <- "NetBeans"
Input$Tool[Input$Tool == "intellj"] <- "Intellij"
Input$Tool[Input$Tool == "rjtl"] <- "Rjtl"

#Input <- subset(Input, Tool == "Rjtl")
#Input <- subset(Input, Tool == "Intellij")
#Input <- subset(Input, Tool == "NetBeans")

Input <- subset(Input, Transformation!="512" & Transformation!="511" & Transformation!="518" & Transformation!="481")
Input <- subset(Input, Transformation!="534" & Transformation!="463" & Transformation!="535" & Transformation!="539")

ds <- Input[ , -which(names(Input) %in% c("Tool"))]

library(reshape2)
options("scipen"=100, "digits"=4)


sloc <- ds[,c(1,2,3)]
slocDifference <- ds[,c(1,2,3)]
colnames(sloc) <- c("Id", "Before", "After")
sloc$Before <- gsub(",", ".", sloc$Before)
sloc$After <- gsub(",", ".", sloc$After)
sloc$Before <- as.numeric(sloc$Before)
sloc$After <- as.numeric(sloc$After)
slocR <- melt(sloc, id.vars=c("Id"), variable.name="Kind", value.name="SLOC")

cc <- ds[,c(1,4,5)]
ccDifference <- ds[,c(1,4,5)]
colnames(cc) <- c("Id", "Before", "After")
cc$Before <- gsub(",", ".", cc$Before)
cc$After <- gsub(",", ".", cc$After)
cc$Before <- as.numeric(cc$Before)
cc$After <- as.numeric(cc$After)
ccR <- melt(cc, id.vars=c("Id"), variable.name="Kind", value.name="CC")

slocDifference["Difference"] <- slocDifference$Loc_Before - slocDifference$Loc_After
ccDifference["Difference"] <- ccDifference$Complex_Before - ccDifference$Complex_After

slocDifference["Improvement"] <- ifelse(slocDifference$Difference < 0, "Decrease", ifelse(slocDifference$Difference > 0, "Increase", "Unchanged"))
ccDifference["Improvement"] <- ifelse(ccDifference$Difference < 0, "Decrease", ifelse(ccDifference$Difference > 0, "Increase", "Unchanged"))

slocDifference$Improvement <- as.factor(slocDifference$Improvement)
ccDifference$Improvement <- as.factor(ccDifference$Improvement)
summary(slocDifference)
summary(ccDifference)

posnett <- ds[,c(1,6,7)]
colnames(posnett) <- c("Id", "Before", "After")
posnett$Before <- gsub(",", ".", posnett$Before)
posnett$After <- gsub(",", ".", posnett$After)
summary(ccDifference)
posnett$Before <- as.double(posnett$Before)
posnett$After <- as.double(posnett$After)
#sapply(posnett, class)
posnettR <- melt(posnett, id.vars=c("Id"), variable.name="Kind", value.name="Posnett")
posnett["Difference"] <- posnett$Before - posnett$After
posnett["Improvement"] <- ifelse(posnett$Before < posnett$After, TRUE, ifelse(posnett$Before == posnett$After, "EQUAL", FALSE))
wilcox.test(posnett$Before, posnett$After, paired=TRUE)
posnett$Improvement <- as.factor(posnett$Improvement)
summary(posnett)
posnett$Improvement


buse <- ds[,c(1,8,9)]
colnames(buse) <- c("Id", "Before", "After")
buse$Before <- gsub(",", ".", buse$Before)
buse$After <- gsub(",", ".", buse$After)
buse$Before <- as.double(buse$Before)
buse$After <- as.double(buse$After)
buseR <- melt(buse, id.vars=c("Id"), variable.name="Kind", value.name="Buse")
buse["Difference"] <- buse$Before - buse$After
buse["Improvement"] <- ifelse(buse$Before < buse$After, TRUE, ifelse(buse$Before == buse$After, "EQUAL", FALSE))
wilcox.test(buse$Before, buse$After, paired=TRUE)
buse$Improvement <- as.factor(buse$Improvement)
summary(buse)
nrow(buse[buse$Difference == 0,])


## estimate the effect on the readability metrics using sloc and cc

 head(sloc)
 head(cc)
 head(posnett)
 head(buse)

 sloc["SLOCDiff"] <- sloc["After"] - sloc["Before"]
 cc["CCDiff"] <- cc["After"] - cc["Before"]
 buse["BDiff"] = buse["Difference"]
 posnett["PDiff"] = posnett["Difference"]


 finalDS <- merge(sloc[,c("Id", "SLOCDiff")], cc[,c("Id", "CCDiff")])
 finalDS <- merge(finalDS, buse[, c("Id", "BDiff")])
 finalDS <- merge(finalDS, posnett[, c("Id", "PDiff")])


 mod1 <- lm(BDiff ~ SLOCDiff + CCDiff, data = finalDS)
 mod2 <- lm(PDiff ~ SLOCDiff + CCDiff, data = finalDS)

 library(xtable)
 tab1 <- xtable(summary(mod1))
 tab2 <- xtable(summary(mod2))
 
 print(tab1)
 print(tab2)
 
 # modelSummary <- summary(mod1)  # capture model summary as an object
 # modelCoeffs <- modelSummary$coefficients  # model coefficients
 # beta.estimate <- modelCoeffs["CCDiff", "Estimate"]  # get beta estimate for speed
 # std.error <- modelCoeffs["CCDiff", "Std. Error"]  # get std.error for speed
 # t_value <- beta.estimate/std.error  # calc t statistic
 # p_value <- 2*pt(-abs(t_value), df=nrow(posnett)-ncol(posnett))  # calc p Value
 # f_statistic <- mod1$  # fstatistic
 # f <- summary(mod1)$fstatistic  # parameters for model p-value calc
 # model_p <- pf(f[1], f[2], f[3], lower=FALSE)

