SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

SELECT x.diff_id,x.Tool as Tool, x._Type as _Type, x.Transformation as Transformation
, h._Before as Loc_Before
, h._After as Loc_After
, j._Before as Complex_Before
, j._After as Complex_After
, TRIM((Replace(replace(x._Before, '.',','),'\n',''))) as Posnet_Before
, TRIM((Replace(replace(x._After, '.',','),'\n',''))) as Posnet_After
, TRIM((Replace(replace(o._Before, '.',','),'\n',''))) as RayBuse_Before
, TRIM((Replace(replace(o._After, '.',','),'\n',''))) as RayBuse_After
-- , cast(x._Before as decimal(11,3)) as Posnet_Before
-- , cast(x._After as decimal(11,3)) as Posnet_After
-- , cast(o._Before as decimal(11,3)) as RayBuse_Before
-- , cast(o._After as decimal(11,3)) as RayBuse_After
from
(SELECT tr.diff_id,tr.id as Transformation,tr.ide as Tool, tt.description as _Type, re.before as _Before, re.after as _After 
FROM transformation_types as tt
inner join transformations as tr on tr.transformation_type_id = tt.id
inner join results as re on re.transformation_id = tr.id
inner join metrics as me on re.metric_id = me.id
where tr.apt = 'S' and me.metric_type_id = 3 and (re.metric_id = 6)) x

inner join

(SELECT tr.diff_id,tr.id as Transformation,tr.ide as Tool, tt.description as _Type, re.before as _Before, re.after as _After 
FROM transformation_types as tt
inner join transformations as tr on tr.transformation_type_id = tt.id
inner join results as re on re.transformation_id = tr.id
inner join metrics as me on re.metric_id = me.id
where tr.apt = 'S' and me.metric_type_id = 3 and (re.metric_id = 1)) h on x.Transformation = h.Transformation


inner join

(SELECT tr.diff_id,tr.id as Transformation,tr.ide as Tool, tt.description as _Type, re.before as _Before, re.after as _After 
FROM transformation_types as tt
inner join transformations as tr on tr.transformation_type_id = tt.id
inner join results as re on re.transformation_id = tr.id
inner join metrics as me on re.metric_id = me.id
where tr.apt = 'S' and me.metric_type_id = 3 and (re.metric_id = 2)) j on x.Transformation = j.Transformation

inner join

(SELECT tr.diff_id,tr.id as Transformation,tr.ide as Tool, tt.description as _Type, re.before as _Before, re.after as _After 
FROM transformation_types as tt
inner join transformations as tr on tr.transformation_type_id = tt.id
inner join results as re on re.transformation_id = tr.id
inner join metrics as me on re.metric_id = me.id
where tr.apt = 'S' and me.metric_type_id = 3 and (re.metric_id = 5)) o on x.Transformation = o.Transformation

group by 4
order by 2,3