select x.user_id as Participant, x.transformation_id as Transformation, x.transformation_type_id as Type 
, x.justify as Q12
from 
(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.justify

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where u.trophy = 42 and qst.id = 12 and an.justify != 'N/A') x

group by 1,2
order by 3