select x.site_link	,x.transformation_id as Transformation, x.description as Type 
, right(x.choice,1) as Q1
-- , y.choice as Q2
-- , z.choice as Q3
-- , j.choice as Q4
-- , h.choice as Q5
-- , k.choice as Q6
-- , l.choice as Q7
from 
(SELECT ul.experience, u.profession, u.functional_program, u.formation, an.user_id, res.transformation_id, ty.description, qst.id, an.choice, tr.site_link

FROM users u
inner join user_languages as ul on ul.user_id = u.id
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
inner join transformation_types as ty on tr.transformation_type_id = ty.id
where u.status = 1 and u.trophy = 42 and qst.id = 2) x

-- inner join 
-- 
-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 3) y on x.user_id = y.user_id
-- 
-- inner join
-- 
-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 4) z on x.user_id = z.user_id

-- inner join 

-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 24) j on x.user_id = j.user_id
-- 
-- inner join 
-- 
-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 25) h on x.user_id = h.user_id
-- 
-- inner join 
-- 
-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 26) k on x.user_id = k.user_id
-- 
-- 
-- inner join 
-- 
-- (SELECT u.profession,u.formation,u.functional_program, an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice
-- 
-- FROM users u
-- inner join answers as an on u.id = an.user_id
-- inner join result_questions as rq on rq.id = an.result_question_id
-- inner join questions as qst on rq.question_id = qst.id
-- inner join results as res on rq.result_id = res.id
-- inner join transformations as tr on res.transformation_id = tr.id
-- where u.status = 1 and u.trophy = 42 and qst.id = 27) l on x.user_id = l.user_id

group by 1
order by 1