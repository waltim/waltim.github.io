if(!require(psych)){install.packages("psych", dependencies = TRUE)}
if(!require(likert)){install.packages("likert", dependencies = TRUE)}

library(readxl)
Dataset1 <- read_excel("Documentos/lambdaanalysisresults/dataset1/Dataset1.xls")
Input <- Qar_Dataset[ , -which(names(Qar_Dataset) %in% c("Participant","Transformation","Type","Q2","Q3","Q4","Q5"))]
Data <- as.data.frame(Input)

Profession <- as.data.frame(Input[ , -which(names(Input) %in% c("Formation"))])

Formation <- as.data.frame(Input[ , -which(names(Input) %in% c("Profession"))])

Profession$Q1 = factor(Profession$Profession,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

                 Formation$Q1 = factor(Formation$Q1,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

### Change Likert scores to factor and specify levels
Data$Q1 = factor(Data$Q1,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q2 = factor(Data$Q2,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q3 = factor(Data$Q3,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q4 = factor(Data$Q4,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q5 = factor(Data$Q5,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

                 Data$Q6 = factor(Data$Q6,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

                 Data$Q7 = factor(Data$Q7,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

levels(Data$Q1) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q2) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q3) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q4) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q5) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q6) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")
levels(Data$Q7) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")


Formation$Formation = factor(Formation$Q1, levels=unique(Formation$Formation))

Profession$Profession = factor(Profession$Q1, levels=unique(Profession$Formation))

Formation$Q1.f = factor(Formation$Q1,
                       ordered = TRUE)

Profession$Q1.f = factor(Profession$Q1,
                       ordered = TRUE)


XT = xtabs( ~ Profession + Q1.f,
       data = Profession)                                             

YT = xtabs( ~ Formation + Q1.f,
       data = Formation)

prop.table(XT,
           margin = 1)

prop.table(YT,
           margin = 1)

Question <- Data[ , -which(names(Data) %in% c("Q1","Q2","Q3","Q4","Q5","Q6","Q7"))]
Question$Profession <- NULL
Question$Transformation <- NULL
Question$FunctionalProgram <- NULL

colnames(Question) <- c("")
# Do you agree that this transformation improves?
colnames(Question) <- c("Do you agree that this transformation improves Reusability?")
colnames(Question) <- c("Do you agree that this transformation improves Flexibility?")
colnames(Question) <- c("Do you agree that this transformation improves Performance?")
colnames(Question) <- c("Do you agree that this transformation improves Testability?")

# Question <- Data[ , -which(names(Data) %in% c("Q2","Q3","Q4","Q5"))]
# Question <- Data[ , -which(names(Data) %in% c("Q1","Q3","Q4","Q5"))]
# Question <- Data[ , -which(names(Data) %in% c("Q1","Q2","Q4","Q5"))]
# Question <- Data[ , -which(names(Data) %in% c("Q1","Q2","Q3","Q5"))]
# Question <- Data[ , -which(names(Data) %in% c("Q1","Q2","Q3","Q4"))]

# colnames(Question) <- c("Transformation",
# "Has the adoption of lambda expressions in code 2 improved readability?")
# colnames(Question) <- c("Transformation",
#  "Is it easy to understand the transformation purpose?")
#  colnames(Question) <- c("Transformation",
#  "Considering this particular transformation, do you agree that it should be applied?")
#  colnames(Question) <- c("Transformation",
#  "Is the reduction in the quantity of branches (repetition loops like ‘for’ or ‘while’ and conditional sentences as if-then-else or switch cases) relevant to asses the transformation quality?")
#  colnames(Question) <- c("Transformation",
#  "Is the number of code lines reducing relevant to assess the quality of the transformation?")

# Question$Transformation <- NULL
# Data$Q1 <- NULL
# Data$Q2 <- NULL
# Data$Q3 <- NULL
# Data$Q4 <- NULL
# Data$Q5 <- NULL
### Double check the data frame

# colnames(Question) <- c('')

library(psych)

headTail(Question)

str(Question)

library(likert)

likert(Question)

# Result = likert(Question)

lik2 <- likert(as.data.frame(Question), grouping = Input$Transformation)
plot(lik2, wrap = 60, text.size=4) + theme(axis.text.y = element_text(size="10"))


rm(lik2,Question)

### responses are grouped into "low", "neutral", and "high"
summary(Result)

### for the percent numbers, responses are grouped into "low", "neutral", and "high"

pdf("dataset1barQ2.pdf", width = 20, height = 6)

# plot(Result, 
#      type="bar",
#      text.size = 8, 
#      wrap = 50)

plot(Result, wrap = 60, text.size=8, cex.lab = 5) + theme(axis.text.y = element_text(size="15"))

dev.off()



pdf("dataset1heat.pdf")

plot(Result, 
     type="heat",
     low.color = "white", 
     high.color = "blue",
     text.color = "black", 
     text.size = 4, 
     wrap = 50)
     + theme(axis.text.y = element_text(size="15")

dev.off()

### Vertical lines are means for each group.
### Curves are density plots, which show the distribution of values similar to a histogram.

pdf("dataset1density.pdf")

plot(Result,
     type="density",
     facet = TRUE, 
     bw = 0.5)

dev.off()