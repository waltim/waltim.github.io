if(!require(psych)){install.packages("psych")}
if(!require(FSA)){install.packages("FSA")}
if(!require(lattice)){install.packages("lattice")}
if(!require(coin)){install.packages("coin")}
if(!require(rcompanion)){install.packages("rcompanion")}
if(!require(multcompView)){install.packages("multcompView")}
if(!require(ggplot2)){install.packages("ggplot2")}
if(!require(plyr)){install.packages("plyr")}

Data <- read.csv("users-information-q1.csv", header = TRUE, sep = ";")

Data <- read.csv("C:/Users/03873243130/Desktop/lambdaanalysisresults/dataset1/users-information-q1.csv", header = TRUE, sep = ";")

Data

Input <- Data[ , -which(names(Data) %in% c("Participant","Formation","Java_Experience","FunctionalProgram","Profession","Transformation","Type"))]
Input <- Data[ , -which(names(Data) %in% c("Participant","Java_Experience","FunctionalProgram","Profession","Transformation","Type"))]
Input
colnames(Input) <- c("JavaExp", "Q1")
Java_Experience

levels(Input$Java_Experience) <- c("1"="1 year", "2", "3", "4", "5","6","7","8","9","10","11")

Input$JavaExp <- as.character(Input$JavaExp)

Input$JavaExp <- revalue(Input$JavaExp, c("1"="1 year"))
Input$JavaExp <- revalue(Input$JavaExp, c("2"="2 to 3 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("3"="2 to 3 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("4"="4 to 5 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("5"="4 to 5 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("6"="6 to 7 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("7"="6 to 7 years"))
Input$JavaExp <- revalue(Input$JavaExp, c("8"="8 or more years"))
Input$JavaExp <- revalue(Input$JavaExp, c("9"="8 or more years"))
Input$JavaExp <- revalue(Input$JavaExp, c("10"="8 or more years"))
Input$JavaExp <- revalue(Input$JavaExp, c("11"="8 or more years"))


Input$FunctionalProgram <- revalue(Input$FunctionalProgram, c("1"="1 year"))
Input$FunctionalProgram <- revalue(Input$FunctionalProgram, c("1-4"="1 to 4 years"))
Input$FunctionalProgram <- revalue(Input$FunctionalProgram, c("4-5"="4 to 5 years"))
Input$FunctionalProgram <- revalue(Input$FunctionalProgram, c("5+"="5 or more years"))
Input$FunctionalProgram <- revalue(Input$FunctionalProgram, c("NC"="Without experience"))


Input$Profession <- revalue(Input$Profession, c("DJ"="Developer"))
Input$Profession <- revalue(Input$Profession, c("DP"="Developer"))
Input$Profession <- revalue(Input$Profession, c("AD"="Analyst Developer"))
Input$Profession <- revalue(Input$Profession, c("DS"="Senior Developer"))
Input$Profession <- revalue(Input$Profession, c("OT"="Developer"))


Input$Formation <- revalue(Input$Formation, c("DC"="PhD"))
Input$Formation <- revalue(Input$Formation, c("PGC"="Graduated"))
Input$Formation <- revalue(Input$Formation, c("SC"="Graduated"))
Input$Formation <- revalue(Input$Formation, c("SI"="Student"))
Input$Formation <- revalue(Input$Formation, c("PGI"="Graduated"))
Input$Formation <- revalue(Input$Formation, c("MM"="Master"))

Input$FunctionalProgram = factor(Input$FunctionalProgram, levels=unique(Input$FunctionalProgram))

Input

Input$Likert.f = factor(Input$Q1,
                       ordered = TRUE)

Input

library(psych)

headTail(Input)

str(Input)

summary(Input)

xtabs( ~ FunctionalProgram + Likert.f,
      data = Input)

XT = xtabs( ~ FunctionalProgram + Likert.f,
           data = Input)

prop.table(XT, 
           margin = 1)

library(lattice)

histogram(~ Likert.f | FunctionalProgram,
          data=Input,
          layout=c(1,6))

library(coin)

independence_test(Likert.f ~ Formation,
                  data = Input)

library(rcompanion)

PT = pairwisePermutationTest(Likert.f ~ Formation,
                             data   = Input,
                             method = "fdr")

PT


###---JavaExp---###
        Asymptotic General Independence Test

data:  Likert.f (ordered) by
         JavaExp (1 year, 4 to 5 years, 8 or more years, 2 to 3 years, 6 to 7 years)
maxT = 0.61341, p-value = 0.9604
alternative hypothesis: two.sided


###---FunctionalProgram---###

Asymptotic General Independence Test

data:  Likert.f (ordered) by
         FunctionalProgram (1 year, 1 to 4 years, 5 or more years, 4 to 5 years, I never program)
maxT = 2.4684, p-value = 0.06317
alternative hypothesis: two.sided


###---Formation---###


 Asymptotic General Independence Test

data:  Likert.f (ordered) by Formation (Student, Graduated, Master, PhD)
maxT = 2.8433, p-value = 0.01684
alternative hypothesis: two.sided



               Comparison    Stat  p.value p.adjust
1 Student - Graduated = 0 -0.6022   0.5471  0.54710
2    Student - Master = 0   1.671  0.09477  0.14220
3       Student - PhD = 0   2.092  0.03647  0.07294
4  Graduated - Master = 0   2.887 0.003888  0.01757
5     Graduated - PhD = 0   2.756 0.005857  0.01757
6        Master - PhD = 0  0.7425   0.4578  0.54710



###---Profession---###

Asymptotic General Independence Test

data:  Likert.f (ordered) by Profession (Developer, Analyst Developer, Senior Developer)
maxT = 1.4212, p-value = 0.3255
alternative hypothesis: two.sided



dat1 <- data.frame(
    sex = factor(c("Before","After","Participants","Before","After","Participants","Before","After","Participants","Before","After","Participants","Before","After","Participants","Before","After","Participants","Before","After","Participants","Before","After","Participants")),
    time = factor(c("1180","1180","1180","1192","1192","1192","1193","1193","1193","1092","1092","1092","1187","1187","1187","1195","1195","1195","1196","1196","1196","1094","1094","1094"), levels=c("1180","1192","1193","1092","1187","1195","1196","1094")),
    total_bill = c(0.87,0.68,0.56,0.47,0.58,0.96,0.87,0.68,0.56,0.47,0.58,0.96,0.87,0.68,0.56,0.47,0.58,0.96,0.87,0.68,0.56,0.47,0.58,0.96)
)
dat1


ggplot(data=dat1, aes(x=time, y=total_bill, fill=sex)) +
    geom_bar(stat="identity", position=position_dodge(), colour="black") +
    scale_fill_manual(values=c("#E69F00", "#999999","blue"))