if(!require(psych)){install.packages("psych")}
if(!require(likert)){install.packages("likert")}

library(readxl)

Dataset1ChosenCode <- read_excel("dataset1/Dataset1ChosenCode.xls")

Input <- Dataset1ChosenCode[ , -which(names(Dataset1ChosenCode) %in% c("Participant","Transformation","Type"))]
Data <- as.data.frame(Input)

### Change Likert scores to factor and specify levels
Data$Q6 = factor(Data$Q6,
                 levels = c("1", "2"),
                 ordered = TRUE)


### Double check the data frame

library(psych)

headTail(Data)

str(Data)

library(likert)

likert(Data)

Result = likert(Data)

### responses are grouped into "low", "neutral", and "high"
summary(Result)

### for the percent numbers, responses are grouped into "low", "neutral", and "high"

pdf("Dataset1ChosenCodebar.pdf")

plot(Result,
     type="bar")

dev.off()

pdf("Dataset1ChosenCodeheat.pdf")

plot(Result, 
     type="heat",
     low.color = "white", 
     high.color = "blue",
     text.color = "black", 
     text.size = 4, 
     wrap = 50)

dev.off()

### Vertical lines are means for each group.
### Curves are density plots, which show the distribution of values similar to a histogram.

pdf("Dataset1ChosenCodedensity.pdf")

plot(Result,
     type="density",
     facet = TRUE, 
     bw = 0.5)

dev.off()