if(!require(psych)){install.packages("psych")}
if(!require(likert)){install.packages("likert")}

library(readxl)

sheetName <- toString("1027")
barName <- toString(paste(sheetName, "bar.pdf", sep="-"))
heatName <- toString(paste(sheetName, "heat.pdf", sep="-"))
densityName <- toString(paste(sheetName, "density.pdf", sep="-"))

dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/Dataset1Transformation.xls", sheet = sheetName, range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1035", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1052", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1062", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1166", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1180", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1182", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1183", range = "D1:H15")
###dataset1transformation <- read_excel("Documentos/lambdaanalysisresults/dataset1/dataset1transformation.xls", sheet = "1192", range = "D1:H15")
Data <- as.data.frame(dataset1transformation)

### Change Likert scores to factor and specify levels
Data$Q1 = factor(Data$Q1,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q2 = factor(Data$Q2,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q3 = factor(Data$Q3,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q4 = factor(Data$Q4,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q5 = factor(Data$Q5,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

### Double check the data frame

library(psych)

headTail(Data)

str(Data)

library(likert)

likert(Data)

Result = likert(Data)

### responses are grouped into "low", "neutral", and "high"
summary(Result)

### for the percent numbers, responses are grouped into "low", "neutral", and "high"

pdf(barName)

plot(Result,
     type="bar")

dev.off()

pdf(heatName)

plot(Result, 
     type="heat",
     low.color = "white", 
     high.color = "blue",
     text.color = "black", 
     text.size = 4, 
     wrap = 50)

dev.off()

### Vertical lines are means for each group.
### Curves are density plots, which show the distribution of values similar to a histogram.

pdf(densityName)

plot(Result,
     type="density",
     facet = TRUE, 
     bw = 0.5)

dev.off()