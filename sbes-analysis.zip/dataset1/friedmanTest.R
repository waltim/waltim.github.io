install.packages("PMCMR")
install.packages("reshape2")

library(readxl)
Qar_Dataset <- read_excel("Documentos/lambdaanalysisresults/Qar-Dataset.xls")
View(Qar_Dataset)                                                                                                                  
Data <- Qar_Dataset[ , -which(names(Qar_Dataset) %in% c("Transformation","Type","Formation","Profession"))]
View(Data)
dataMatrix <- data.matrix(Data)

library(reshape2)
myDataLong<-melt(Data, id.vars = c("Participant"))

library(stats)
friedman.test(dataMatrix)
library(PMCMR)
posthoc.friedman.nemenyi.test(dataMatrix)

