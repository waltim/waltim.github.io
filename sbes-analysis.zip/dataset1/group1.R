if(!require(psych)){install.packages("psych")}
if(!require(likert)){install.packages("likert")}

library(readxl)

group1 <- read_excel("dataset1/dataset1group1.xls", range = "D1:H85")
Data <- as.data.frame(group1)

### Change Likert scores to factor and specify levels
Data$Q2 = factor(Data$Q2,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q3 = factor(Data$Q3,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q4 = factor(Data$Q4,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q5 = factor(Data$Q5,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

Data$Q6 = factor(Data$Q6,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

### Double check the data frame

library(psych)

headTail(Data)

str(Data)

library(likert)

likert(Data)

Result = likert(Data)

### responses are grouped into "low", "neutral", and "high"
summary(Result)

### for the percent numbers, responses are grouped into "low", "neutral", and "high"

pdf("group1bar.pdf")

plot(Result,
     type="bar")

dev.off()

pdf("group1heat.pdf")

plot(Result, 
     type="heat",
     low.color = "white", 
     high.color = "blue",
     text.color = "black", 
     text.size = 4, 
     wrap = 50)

dev.off()

### Vertical lines are means for each group.
### Curves are density plots, which show the distribution of values similar to a histogram.

pdf("group1density.pdf")

plot(Result,
     type="density",
     facet = TRUE, 
     bw = 0.5)

dev.off()