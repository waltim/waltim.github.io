if(!require(psych)){install.packages("psych")}
if(!require(likert)){install.packages("likert")}

SQ1_all_study <- read.csv("C:/Users/03873243130/Desktop/lambdaanalysisresults/allTransformationMetrics/SQ1-all-study.csv", header = TRUE, sep = ";")
View(SQ1_all_study)

Input <- SQ1_all_study[ , -which(names(SQ1_all_study) %in% c("Transformation"))]
Data <- as.data.frame(Input)

Data$Q1 = factor(Data$Q1,
                 levels = c("1", "2", "3", "4", "5"),
                 ordered = TRUE)

levels(Data$Q1) <- c("Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree")

Input$X_Type = factor(Input$X_Type, levels=unique(Input$X_Type))

Data$X_Type <- NULL

colnames(Data) <- c("Has the adoption of lambda expressions in the transformed code improved readability?")

library(psych)

headTail(Data)

str(Data)

library(likert)


likert(Data)

Result = likert(Data)

lik2 <- likert(as.data.frame(Data$Q1), grouping = Input$X_Type)
plot(lik2, wrap = 60, text.size=4) + theme(axis.text.y = element_text(size="10"))