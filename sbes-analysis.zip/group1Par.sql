select x.user_id as Participant, x.transformation_id as Transformation, x.transformation_type_id as Type 
, right(x.choice,1) as Q2
, y.choice as Q3
, z.choice as Q4
, j.choice as Q5
, h.choice as Q6
from 
(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where qst.id <= 6 and MOD(an.user_id,2) = 0 and u.trophy = 42 and qst.id = 2) x

inner join 

(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where qst.id <= 6 and MOD(an.user_id,2) = 0 and u.trophy = 42 and qst.id = 3) y on x.user_id = y.user_id

inner join

(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where qst.id <= 6 and MOD(an.user_id,2) = 0 and u.trophy = 42 and qst.id = 4) z on x.user_id = z.user_id

inner join 

(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where qst.id <= 6 and MOD(an.user_id,2) = 0 and u.trophy = 42 and qst.id = 5) j on x.user_id = j.user_id

inner join 

(SELECT an.user_id, res.transformation_id,tr.transformation_type_id, qst.id, an.choice

FROM users u
inner join answers as an on u.id = an.user_id
inner join result_questions as rq on rq.id = an.result_question_id
inner join questions as qst on rq.question_id = qst.id
inner join results as res on rq.result_id = res.id
inner join transformations as tr on res.transformation_id = tr.id
where qst.id <= 6 and MOD(an.user_id,2) = 0 and u.trophy = 42 and qst.id = 6) h on x.user_id = h.user_id

group by 1,2
order by 1,3


